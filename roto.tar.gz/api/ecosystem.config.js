module.exports = {
    apps : [{
      name: "api",
      script: "./bin/www",
    }]
  }